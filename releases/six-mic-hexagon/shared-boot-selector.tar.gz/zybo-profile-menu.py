"""Select a Zybo boot profile or load a partial via the active audio driver."""

import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import termios
import textwrap
import tty


SELECTOR = "/usr/sbin/zybo-profile.sh"
AUDIO = "/usr/bin/zybo-audio"
PROFILES = (
    ("hash", "FPGA DFX Hash Accelerator",
     "Hardware hashing through AXI DMA. The hash service selects SHA3-256, SHA-256 or BLAKE2s per request."),
    ("fx", "ZyboFX Single Effects",
     "Stereo codec and one reconfigurable effect slot. Load bypass, overdrive, distortion, fuzz, tremolo, chorus or delay."),
    ("chain4", "ZyboFX Chain4 and Studio",
     "Stereo multi-effect chain and compatible Studio pipelines. The two share a full bitstream and device tree."),
    ("vision", "ZyboVision",
     "Convolution tile with a Linux register status tool. Run zybovision-status after boot."),
    ("radar", "Acoustic Radar",
     "Capture six synchronized microphones. Connect the acoustic radar dashboard over USB UART."),
    ("rescue", "Linux Rescue",
     "Boot the shared filesystem and serial console without programming the FPGA or probing FPGA devices."),
)
FX = ("BYPASS", "OVERDRIVE", "DISTORTION", "FUZZ", "TREMOLO", "CHORUS", "DELAY")


def read_key(fd):
    key = os.read(fd, 1)
    if key != b"\x1b":
        return {b"\r": "enter", b"\n": "enter", b"k": "up", b"j": "down",
                b"q": "back", b"": "back", b"\x04": "back"}.get(key)
    if not select.select([fd], [], [], 0.25)[0]:
        return "back"
    if os.read(fd, 1) not in (b"[", b"O"):
        return None
    if not select.select([fd], [], [], 0.25)[0]:
        return None
    return {b"A": "up", b"B": "down"}.get(os.read(fd, 1))


def choose(title, items, details=(), initial=0):
    fd = sys.stdin.fileno()
    saved = termios.tcgetattr(fd)
    current = initial
    try:
        tty.setcbreak(fd)
        while True:
            size = shutil.get_terminal_size((80, 24))
            width = max(20, size.columns)
            header = [title, *details]
            lines = [line for paragraph in header
                     for line in textwrap.wrap(paragraph, width) or [""]]
            room = max(1, size.lines - len(lines) - 3)
            start = max(0, min(current - room // 2, len(items) - room))
            for index in range(start, min(start + room, len(items))):
                label = ("> " if index == current else "  ") + items[index]
                lines.append(label[:width])
            lines.extend(("", "Up/Down  Enter  Esc or q"))
            sys.stdout.write("\x1b[2J\x1b[H" + "\n".join(lines))
            sys.stdout.flush()
            key = read_key(fd)
            if key == "up":
                current = (current - 1) % len(items)
            elif key == "down":
                current = (current + 1) % len(items)
            elif key == "enter":
                return current
            elif key == "back":
                return None
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, saved)
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()


def audio_partials(profile):
    if profile == "fx":
        return [(effect.title(), ["FX", effect]) for effect in FX]
    partials = [("Bypass", ["FX", "BYPASS"]), ("Chain4", ["FX", "CHAIN4"])]
    index = Path("/opt/zybo/chain4/pipelines/index.json")
    if index.is_file():
        for name, entry in sorted(json.loads(index.read_text()).items()):
            label = name.replace("-", " ").title()
            partials.append((label, ["LOAD", entry["build_id"]]))
    return partials


def select_partial(profile):
    partials = audio_partials(profile)
    index = choose("Runtime partial bitstreams", [label for label, _ in partials],
                   ("Linux loads these through the current project's audio controller.", ""))
    if index is None:
        return None
    label, command = partials[index]
    action = choose(label, ("Load now", "Load now and restore on startup", "Back"))
    if action == 0:
        return [AUDIO, *command]
    if action == 1:
        return [AUDIO, "remember", *command]
    return None


def main():
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print("The menu needs an interactive terminal. Use zybo-profile list or select PROFILE.",
              file=sys.stderr)
        return 2
    active = subprocess.check_output([SELECTOR, "active"], text=True).strip()
    selection = Path("/boot/profile.env")
    next_profile = next((line.removeprefix("zybo_profile=")
                         for line in selection.read_text().splitlines()
                         if line.startswith("zybo_profile=")), "") if selection.is_file() else ""
    profiles = [entry for entry in PROFILES
                if entry[0] != "radar" or Path("/boot/profiles/radar/system.bit").is_file()]
    labels = [f"{name}  [{profile}]" for profile, name, _ in profiles]
    current = next((i for i, (profile, _, _) in enumerate(profiles) if profile == next_profile), 0)
    while True:
        index = choose("Zybo bitstream and device tree", labels,
                       (f"Running: {active or 'unknown'}    Next boot: {next_profile or 'unset'}",
                        "Enter opens project details.", ""), current)
        if index is None:
            return 0
        current = index
        profile, name, description = profiles[index]
        bitstream = f"/boot/profiles/{profile}/system.bit" if profile != "rescue" else "Skipped"
        details = (description, f"Full bitstream: {bitstream}",
                   f"Device tree: /boot/profiles/{profile}/system.dtb", "")
        actions = ["Save for next boot", "Save and reboot now"]
        can_load_partials = profile == active and profile in ("fx", "chain4")
        if can_load_partials:
            actions.append("Browse and load runtime partials")
        actions.append("Back")
        action = choose(name, actions, details)
        command = None
        if action in (0, 1):
            command = [SELECTOR, "select" if action == 0 else "switch", profile]
        elif can_load_partials and action == 2:
            command = select_partial(profile)
        if command:
            os.execv(command[0], command)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
