#!/bin/sh
set -eu

if [ "$#" -eq 0 ] && [ -t 0 ] && [ -t 1 ]; then
    set -- menu
fi

active_profile() {
    sed -n 's/.* zybo\.profile=\([a-z0-9]*\).*/\1/p' /proc/cmdline
}

boot_ready() {
    if ! mountpoint -q /boot || [ ! -f /boot/boot.scr ]; then
        echo "The Zybo boot partition is not mounted at /boot." >&2
        return 1
    fi
}

case "${1:-status}" in
    menu)
        exec /usr/bin/python3 /usr/libexec/zybo-profile-menu.py
        ;;
    active)
        active_profile
        ;;
    status)
        p=$(active_profile)
        printf 'Zybo profile: %s\n' "${p:-unknown}"
        case "$p" in
            fx|chain4|hash|vision|radar) printf 'FPGA bitstream: profiles/%s/system.bit\n' "$p" ;;
            rescue) printf '%s\n' 'FPGA bitstream: skipped (rescue)' ;;
        esac
        [ -z "$p" ] || printf 'Device tree: profiles/%s/system.dtb\n' "$p"
        if [ -r /proc/device-tree/model ]; then
            printf 'Board: '
            tr -d '\000' < /proc/device-tree/model
            printf '\n'
        fi
        if mountpoint -q /boot && [ -r /boot/profile.env ]; then
            printf 'Next boot: %s\n' "$(sed -n 's/^zybo_profile=//p' /boot/profile.env | tr -d '\r')"
        fi
        ;;
    list)
        printf '%s\n' 'fx      ZyboFX single effects' 'chain4  ZyboFX Chain4 and Studio' 'hash    FPGA DFX hash accelerator' 'vision  ZyboVision convolution board' 'rescue  Linux without FPGA drivers'
        if [ -s /boot/profiles/radar/system.bit ]; then printf '%s\n' 'radar   Six-microphone acoustic radar'; fi
        ;;
    select|switch)
        [ "$#" -eq 2 ] || { echo "Usage: zybo-profile $1 PROFILE" >&2; exit 2; }
        case "$2" in
            fx|chain4|hash|vision|radar|rescue) ;;
            *) echo "Unknown profile: $2" >&2; exit 2 ;;
        esac
        [ "$(id -u)" -eq 0 ] || { echo 'Run as root to change the boot profile.' >&2; exit 1; }
        boot_ready
        bundle="/boot/profiles/$2"
        [ -s "$bundle/system.dtb" ] && { [ "$2" = rescue ] || [ -s "$bundle/system.bit" ]; } ||
            { echo "Boot files are incomplete for $2." >&2; exit 1; }
        (cd "$bundle" && sha256sum -c SHA256SUMS)
        tmp=$(mktemp /boot/.selection.XXXXXX)
        trap 'rm -f "$tmp"' EXIT
        printf 'zybo_profile=%s\n' "$2" > "$tmp"
        sync
        mv -f "$tmp" /boot/profile.env
        sync
        printf 'Next boot: %s\n' "$2"
        if [ "$1" = switch ]; then reboot; fi
        ;;
    *)
        echo 'Usage: zybo-profile [menu|status|list|select PROFILE|switch PROFILE]' >&2
        exit 2
        ;;
esac
