# The SPL and U-Boot are shared. Configure the PL before Linux probes it.
setenv zybo_profile
if fatload mmc 0:1 0x03100000 profile.env; then
    if env import -t -r 0x03100000 ${filesize} zybo_profile; then
        echo Requested Zybo profile: ${zybo_profile}
    fi
fi

setenv rootuuid
if part uuid mmc 0:2 rootuuid && fatload mmc 0:1 0x02000000 zImage; then
    setenv sharedargs "console=ttyPS0,115200 root=PARTUUID=${rootuuid} rootfstype=ext4 rw rootwait cma=32M"
    setenv profileargs
    setenv fclk_div 0x00200000
    if test "${zybo_profile}" = vision; then
        # Vision is timed at 50 MHz. The other bitstreams use 100 MHz.
        setenv fclk_div 0x00400000
    fi
    if test "${zybo_profile}" = vision || test "${zybo_profile}" = radar; then
        setenv profileargs uio_pdrv_genirq.of_id=generic-uio
    fi

    if test "${zybo_profile}" = hash || test "${zybo_profile}" = fx || test "${zybo_profile}" = chain4 || test "${zybo_profile}" = vision || test "${zybo_profile}" = radar; then
        setenv bundle profiles/${zybo_profile}
        if fatload mmc 0:1 0x03000000 ${bundle}/system.dtb && fdt addr 0x03000000 && fatload mmc 0:1 0x10000000 ${bundle}/system.bit; then
            # Update only FCLK0 DIVISOR1 in the Zynq SLCR, using the values
            # from the two generated PS7 handoffs. Set it before PL startup.
            if setexpr.l zybo_clk *0xf8000170 '&' 0xfc0fffff && setexpr zybo_clk ${zybo_clk} '|' ${fclk_div}; then
                mw.l 0xf8000008 0x0000df0d
                mw.l 0xf8000170 ${zybo_clk}
                mw.l 0xf8000004 0x0000767b
                if fpga loadb 0 0x10000000 ${filesize}; then
                    echo FPGA bitstream: ${bundle}/system.bit
                    echo Device tree: ${bundle}/system.dtb
                    setenv bootargs "${sharedargs} ${profileargs} zybo.profile=${zybo_profile}"
                    bootz 0x02000000 - 0x03000000
                fi
            fi
        fi
        echo Profile boot failed. Trying rescue.
    fi

    if fatload mmc 0:1 0x03000000 profiles/rescue/system.dtb; then
        echo Rescue: booting without FPGA device drivers.
        setenv bootargs "${sharedargs} zybo.profile=rescue"
        bootz 0x02000000 - 0x03000000
    fi
fi
echo Zybo SD boot failed. Check the FAT boot files and ext4 partition.
exit 1
